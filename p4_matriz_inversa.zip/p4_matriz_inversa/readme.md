# Descripción
Código base para el examen final de Métodos Numéricos 2024-A. 

# Indicaciones
* Cero a la prueba en caso de copia, plagio, etc.
* Llegar con puntualidad.
* Tener instalado el software python, numpy, matplotlib, vsCode, Jupyter, etc.
* Traer hoja de papel ministro y calculadora. 